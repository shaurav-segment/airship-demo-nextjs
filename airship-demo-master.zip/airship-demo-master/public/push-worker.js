// 86acbd31cd7c09cf30acb66d2fbedc91daa48b86:1584937937.7140667
importScripts('https://aswpsdkus.com/notify/v1/ua-sdk.min.js')
uaSetup.worker(self, {
  defaultIcon: 'https://whatever.com/favicon.ico',
  defaultTitle: 'Whatever Demo',
  defaultActionURL: 'https://whatever.com',
  appKey: 'REDACTED',
  token: 'REDACTED',
  vapidPublicKey: 'REDACTED'
})
